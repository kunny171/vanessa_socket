<?php
$data = array();
$data['title'] = 'Authentication Required';


pb_backupbuddy::load_view( 'login', $data );